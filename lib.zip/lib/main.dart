import 'package:flutter/material.dart';
import './hermes_app.dart';

void main() => runApp(const HermesApp());