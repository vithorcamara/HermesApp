// ignore_for_file: non_constant_identifier_names

import "package:flutter/material.dart";
double MediaQueryHeight(BuildContext context){return MediaQuery.of(context).size.height;}
double MediaQueryWidth(BuildContext context){return MediaQuery.of(context).size.width;}
